function [] = carrega_variaveis_globais()

    global G_inputs;
    global G_outputs;
    global G_cont;

    G_cont = 0;
    G_inputs = cell(5000,4);
    G_outputs = zeros(5000,1);
    
end

